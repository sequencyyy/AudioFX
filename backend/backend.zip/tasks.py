from celery import Celery
from pydub import AudioSegment
import os
import logging
import redis
import subprocess

celery_app = Celery(
    "tasks", 
    broker="redis://redis:6379/0", 
    backend="redis://redis:6379/0" 
)
celery_app.conf.broker_connection_retry_on_startup = True

# Настройка логгера
logging.basicConfig(
    level=logging.DEBUG,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)

logger = logging.getLogger(__name__)

PROCESSED_DIR = "original"

redis_client = redis.StrictRedis(host="redis", port=6379, decode_responses=True)


@celery_app.task
def remove_vocal_audio(file_path: str, speed: float):
    print(file_path)
    try:
        audio = AudioSegment.from_file(file_path)
        processed_audio = audio._spawn(
            audio.raw_data,
            overrides={"frame_rate": int(audio.frame_rate * speed)},
        )
        output_filename = f"{file_path.split('.mp3')}_processed.mp3"
        output_path = os.path.join(PROCESSED_DIR, output_filename)
        processed_audio.export(output_path, format="mp3")
        return output_path
    except Exception as e:
        raise Exception(f"Error processing file: {e}")

@celery_app.task
def remove_instrumental_audio(file_path: str, speed: float):
    print(file_path)
    try:
        audio = AudioSegment.from_file(file_path)
        processed_audio = audio._spawn(
            audio.raw_data,
            overrides={"frame_rate": int(audio.frame_rate * speed)},
        )
        output_filename = f"{file_path.split('.mp3')}_processed.mp3"
        output_path = os.path.join(PROCESSED_DIR, output_filename)
        processed_audio.export(output_path, format="mp3")
        return output_path
    except Exception as e:
        raise Exception(f"Error processing file: {e}")

@celery_app.task
def nightcore_audio(file_path: str, speed: float):
    print(file_path)
    try:
        audio = AudioSegment.from_file(file_path)
        processed_audio = audio._spawn(
            audio.raw_data,
            overrides={"frame_rate": int(audio.frame_rate * speed)},
        )
        output_filename = f"{file_path.split('.mp3')}_processed.mp3"
        output_path = os.path.join(PROCESSED_DIR, output_filename)
        processed_audio.export(output_path, format="mp3")
        return output_path
    except Exception as e:
        raise Exception(f"Error processing file: {e}")

# @celery_app.task
# def add_reverb_(file_path: str, output_dir: str = "reverbed", reverb_strength: float = 0.5) -> str:
#     """
#     Асинхронная задача для добавления реверберации к аудиофайлу.

#     :param file_path: Путь к исходному аудиофайлу.
#     :param output_dir: Директория для сохранения файла с реверберацией.
#     :param reverb_strength: Сила реверберации (от 0 до 1).
#     :return: Путь к файлу с реверберацией.
#     """
#     # Создаем директорию для выходных файлов, если её нет
#     os.makedirs(output_dir, exist_ok=True)

#     # Генерируем имя выходного файла
#     base_name = os.path.basename(file_path)
#     output_filename = f"reverbed_{base_name}"
#     output_path = os.path.join(output_dir, output_filename)

#     # Используем ffmpeg для добавления реверберации
#     try:
#         subprocess.run(
#             [
#                 "ffmpeg",
#                 "-i", file_path,  # Входной файл
#                 "-af", f"aecho=0.8:0.8:{reverb_strength}:1",  # Фильтр реверберации
#                 output_path       # Выходной файл
#             ],
#             check=True
#         )
#     except subprocess.CalledProcessError as e:
#         raise RuntimeError(f"Error applying reverb: {e}")

#     return output_path

@celery_app.task
def speedup_audio(file_path: str, speed: float, user_id="test_user"):
    print(file_path)
    try:
        audio = AudioSegment.from_file(file_path)
        speedup_audio = audio._spawn(
            audio.raw_data,
            overrides={"frame_rate": int(audio.frame_rate * speed)},
        )
        output_filename = f"{os.path.basename(file_path).split('.mp3')[0]}_speeduped.mp3"
        output_path = os.path.join(PROCESSED_DIR, output_filename)
        speedup_audio.export(output_path, format="mp3")
        print(output_path)
        
        # Сохраняем в Redis только имя файла в качестве ключа (без пути)
        new_redis_key = f"{user_id}:{output_filename}"
        # Но значение должно быть полным путем
        redis_client.set(new_redis_key, output_path)
        
        return output_path
    except Exception as e:
        raise Exception(f"Error processing file: {e}")

@celery_app.task
def slowed_reverb_audio(file_path: str, speed: float, reverb_amount: float, user_id="test_user"):
    print(file_path)
    try:
        audio = AudioSegment.from_file(file_path)
        slowed = audio._spawn(
            audio.raw_data,
            overrides={"frame_rate": int(audio.frame_rate * speed)},
        )
        
        output_slowed_filename = f"{os.path.basename(file_path).split('.mp3')[0]}_slowed.mp3"
        output_slowed_path = os.path.join(PROCESSED_DIR, output_slowed_filename)
        slowed.export(output_slowed_path, format="mp3", bitrate="320k")
        print(output_slowed_path)
        
        output_slowed_reverb_filename = f"{os.path.basename(file_path).split('.mp3')[0]}_slowed_reverb.mp3"
        output_slowed_reverb_path = os.path.join(PROCESSED_DIR, output_slowed_reverb_filename)

        print(output_slowed_reverb_path)
        
        # Удаляем старый файл, если он существует
        if os.path.exists(output_slowed_reverb_filename):
            os.remove(output_slowed_reverb_filename)
        
        subprocess.run(
            [
                "ffmpeg",
                "-y",
                "-i", output_slowed_path,  # Входной файл
                "-af", f"aecho=0.8:0.8:{reverb_amount}:0.5",  # Фильтр реверберации
                "-b:a", '320k',
                "-ar", '44100',
                output_slowed_reverb_path       # Выходной файл
            ],
            check=True
        )
        # Сохраняем в Redis только имя файла в качестве ключа (без пути)
        new_redis_key = f"{user_id}:{output_slowed_reverb_filename}"
        # Но значение должно быть полным путем
        redis_client.set(new_redis_key, output_slowed_reverb_path)
        
        return output_slowed_reverb_path
    except Exception as e:
        raise Exception(f"Error processing file: {e}")
