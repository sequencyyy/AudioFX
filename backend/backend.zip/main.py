from fastapi import FastAPI, File, UploadFile, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import redis
import os
from uuid import uuid4
from datetime import timedelta
from fastapi.responses import FileResponse
from tasks import speedup_audio, slowed_reverb_audio
from celery.result import AsyncResult
import logging
import json

app = FastAPI()

# Настройка логгера
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Настройка CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # Разрешенный домен Frontend
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Подключение к Redis
redis_client = redis.StrictRedis(host="redis", port=6379, decode_responses=True)

ORIGINAL_DIR = "original"

PROCESSED_DIR = "original"
os.makedirs(PROCESSED_DIR, exist_ok=True)
os.makedirs(ORIGINAL_DIR, exist_ok=True)
# Модель для ответа
class ProcessedFile(BaseModel):
    file_id: str
    user_id: str


@app.get("/download/{user_id}/{file_id}")
async def download_processed_file(user_id: str, file_id: str):
    redis_key = f"{user_id}:{file_id}"
    file_path = redis_client.get(redis_key)
    
    
    print(f"Looking for key at: {redis_key}")
    print(f"Looking for file at: {file_path}")  # Логируем путь к файлу

    if not file_path or not os.path.exists(file_path):
        raise HTTPException(status_code=404, detail="File not found or expired")

    return FileResponse(
        path=file_path,
        filename=os.path.basename(file_path),
        media_type="audio/mp3",
    )

@app.get("/status/{task_id}")
async def get_task_status(task_id: str):
    task = AsyncResult(task_id)
    if task.state == "PENDING":
        return {"status": "pending"}
    elif task.state == "SUCCESS":
        # return {"status": "success", "result": task.result}
        return {"status": "success", "result": os.path.basename(task.result)}
    else:
        return {"status": "failed", "error": str(task.info)}

@app.post("/files/")
async def upload_file(
    user_id: str = Query(..., description="ID пользователя"),
    file: UploadFile = File(...)
):
    
    # Генерация уникального имени файла
    file_id = str(file.filename.split('.mp3')[0] + "_" + str(uuid4())[::6])
    file_path = os.path.join(ORIGINAL_DIR, f"{file_id}.mp3")

    # Сохранение файла
    with open(file_path, "wb") as f:
        f.write(await file.read())

    #   Сохранение пути к файлу в Redis с TTL (1 час)
    redis_key = f"{user_id}:{file_id}"
    redis_client.set(redis_key, file_path, ex=timedelta(hours=1))

    return {"message": "File uploaded successfully", "file_id": file_id, "file_path": file_path}


@app.post("/processSpeedUp/")
async def process_speed_up(
    user_id: str = Query(..., description="ID пользователя"),
    file_id: str = Query(..., description="ID файла"),
):
    # Retrieve file path from Redis
    redis_key = f"{user_id}:{file_id}"
    file_path = redis_client.get(redis_key)

    # Создание задачи Celery с передачей user_id
    task = speedup_audio.delay(file_path, speed=1.2, user_id=user_id)
    print(task)

    # Сохраняем информацию о задаче для использования в /status/
    redis_client.set(f"task-info:{task.id}", json.dumps({"user_id": user_id, "file_id": file_id}), ex=3600)
    
    # Store processing status in Redis
    speeduping_key = f"SpeedUp File:{file_id}"
    redis_client.set(speeduping_key, "speeduping", ex=3600)
    
    return {"message": "File SpeedUp'ed successfully", "task_id": task.id, "file_path": file_path}

@app.post("/processSlowedReverb/")
async def process_slowed_reverb(
    user_id: str = Query(..., description="ID пользователя"),
    file_id: str = Query(..., description="ID файла"),
):
    # Retrieve file path from Redis
    redis_key = f"{user_id}:{file_id}"
    file_path = redis_client.get(redis_key)

    # Создание задачи Celery с передачей user_id
    task = slowed_reverb_audio.delay(file_path, speed=0.8, reverb_amount=0.7, user_id=user_id)
    print(task)

    # Сохраняем информацию о задаче для использования в /status/
    redis_client.set(f"task-info:{task.id}", json.dumps({"user_id": user_id, "file_id": file_id}), ex=3600)
    
    # Store processing status in Redis
    slowedreverbing_key = f"SlowedReverb File:{file_id}"
    redis_client.set(slowedreverbing_key, "slowedreverbing_key", ex=3600)
    
    return {"message": "File SlowedReverbing'ed successfully", "task_id": task.id}


